#ifndef WL_DESKTOP_GLSL
#define WL_DESKTOP_GLSL

// The desktop flag. While the compositor runs, its player sits on a seat
// whose height puts the eye (the camera) at block fraction 0.789 in y
// (wm.tc, wmStart). The seat jumps between two spots every tick (for
// held clicks), but both are at the same height, so y stays put.
// Globals.CameraOffset is floor(camera) - camera, the same in every
// pipeline (world and GUI), so any shader can tell the desktop is up.
// Callers include <minecraft:globals.glsl> first.

const float WL_DESK_EYE_FRACTION = 0.789;

bool wl_desktop_active() {
    return abs(-CameraOffset.y - WL_DESK_EYE_FRACTION) < 0.0015;
}

// A clip position outside the view: every vertex moved here draws nothing.
const vec4 WL_HIDDEN = vec4(2.0, 2.0, 2.0, 1.0);

// First-person hand and held item: drawn within a block or so of the camera
// (entity and item pipelines). On the desktop nothing else is that close.
bool wl_hide_near(vec3 position) {
    return wl_desktop_active() && dot(position, position) < 4.0;
}

#endif
